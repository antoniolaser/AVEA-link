package it.avea.link;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int SFONDO = 0xFF0B0E12;
    private static final int CARTA = 0xFF171B21;
    private static final int BORDO = 0xFF2A313B;
    private static final int TESTO = 0xFFF3F5F8;
    private static final int GRIGIO = 0xFF9AA5B4;
    private static final int BLU = 0xFF3DA5F4;
    private static final int VERDE = 0xFF3DD17A;
    private static final int AMBRA = 0xFFF2B13C;
    private static final int SCURO = 0xFF07121C;

    private static final int CHIEDI = 1;

    private LinearLayout radice;
    private boolean modoScelta = false;   // true: si sta scegliendo lo strumento
    // La lista della scelta si congela quando si entra. Ordinata per potenza del segnale, e il
    // segnale balla: senza il fermo immagine i due strumenti si scambiano di posto da soli ogni
    // due secondi, e si finisce per toccare quello sbagliato. Si rinfresca solo con "cerca ancora".
    private List<LinkService.Trovato> listaScelta = new ArrayList<>();
    private final Handler h = new Handler(Looper.getMainLooper());
    private float dp;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        T.load(this);
        dp = getResources().getDisplayMetrics().density;
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(SFONDO);
        radice = new LinearLayout(this);
        radice.setOrientation(LinearLayout.VERTICAL);
        radice.setPadding(px(26), px(34), px(26), px(26));
        sv.addView(radice);
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        disegna();
        h.post(aggiorna);
    }

    @Override
    protected void onPause() {
        h.removeCallbacks(aggiorna);
        super.onPause();
    }

    private final Runnable aggiorna = new Runnable() {
        @Override
        public void run() {
            if (T.chosen() && tuttoApposto()) disegna();
            h.postDelayed(this, 2000);
        }
    };

    // ---- stato dei permessi ----

    private boolean ok(String p) {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean btOk() {
        if (Build.VERSION.SDK_INT >= 31) {
            return ok(Manifest.permission.BLUETOOTH_SCAN) && ok(Manifest.permission.BLUETOOTH_CONNECT);
        }
        return ok(Manifest.permission.ACCESS_FINE_LOCATION);
    }

    private boolean posOk() {
        return ok(Manifest.permission.ACCESS_COARSE_LOCATION) || ok(Manifest.permission.ACCESS_FINE_LOCATION);
    }

    private boolean notifOk() {
        return Build.VERSION.SDK_INT < 33 || ok(Manifest.permission.POST_NOTIFICATIONS);
    }

    private boolean battOk() {
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
    }

    // Il permesso di posizione e l'interruttore della localizzazione sono due cose diverse, e
    // questa differenza costava una chiamata di assistenza. Col permesso dato e l'interruttore
    // spento il telefono non ricava nessuna posizione: niente meteo, e sui telefoni fino ad
    // Android 11 nemmeno la ricerca Bluetooth dello strumento, che la', per legge del sistema,
    // passa dalla localizzazione. La configurazione diceva tutto verde e poi non funzionava
    // niente, senza che niente spiegasse il perche'.
    private boolean locOnOk() {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) return true;   // niente da controllare: non si blocca la configurazione
        try {
            if (Build.VERSION.SDK_INT >= 28) return lm.isLocationEnabled();
            return lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
                || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch (Exception e) {
            return true;
        }
    }

    private boolean tuttoApposto() {
        return btOk() && posOk() && notifOk() && battOk() && locOnOk();
    }

    // ---- disegno delle schermate ----

    private void disegna() {
        radice.removeAllViews();
        if (!T.chosen()) {
            schermataLingua();
        } else if (tuttoApposto()) {
            avviaServizio();
            if (modoScelta) schermataScelta(); else schermataStato();
        } else {
            schermataSetup();
        }
    }

    private void schermataLingua() {
        radice.addView(spazio(60));
        radice.addView(quadrante(96, BLU, VERDE));
        radice.addView(spazio(28));
        radice.addView(testo("AVEA Link", 22, TESTO, true, Gravity.CENTER));
        radice.addView(spazio(10));
        radice.addView(testo(T.s("scegli_lingua") + "   ·   " + versione(), 16, GRIGIO, false, Gravity.CENTER));
        radice.addView(spazio(30));
        radice.addView(bottone("Italiano", new Runnable() {
            @Override public void run() { T.set(MainActivity.this, T.IT); disegna(); }
        }));
        radice.addView(spazio(12));
        radice.addView(bottone("English", new Runnable() {
            @Override public void run() { T.set(MainActivity.this, T.EN); disegna(); }
        }));
    }

    private void schermataSetup() {
        radice.addView(intestazione());
        radice.addView(spazio(20));
        radice.addView(testo(T.s("titolo_setup"), 24, TESTO, true, Gravity.START));
        radice.addView(spazio(8));
        radice.addView(testo(T.s("sotto_setup"), 15, GRIGIO, false, Gravity.START));
        radice.addView(spazio(20));

        radice.addView(carta(T.s("bt"), T.s("bt_sub"), btOk(), T.s("consenti"), new Runnable() {
            @Override public void run() { chiediBt(); }
        }));
        radice.addView(spazio(12));
        radice.addView(carta(T.s("pos"), T.s("pos_sub"), posOk(), T.s("consenti"), new Runnable() {
            @Override public void run() {
                requestPermissions(new String[]{
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION}, CHIEDI);
            }
        }));
        radice.addView(spazio(12));
        radice.addView(carta(T.s("notif"), T.s("notif_sub"), notifOk(), T.s("consenti"), new Runnable() {
            @Override public void run() {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, CHIEDI);
                }
            }
        }));
        radice.addView(spazio(12));
        radice.addView(carta(T.s("batt"), T.s("batt_sub"), battOk(), T.s("attiva"), new Runnable() {
            @Override public void run() { chiediBatteria(); }
        }));
        radice.addView(spazio(12));
        radice.addView(carta(T.s("loc"), T.s("loc_sub"), locOnOk(), T.s("attiva"), new Runnable() {
            @Override public void run() { apriLocalizzazione(); }
        }));

        radice.addView(spazio(22));
        radice.addView(cartaOrigini());
        radice.addView(spazio(20));
        radice.addView(testo(T.s("fine_setup"), 13, GRIGIO, false, Gravity.CENTER));
    }

    private void schermataStato() {
        boolean coll = LinkService.collegato;
        boolean meteo = LinkService.meteoOk;

        radice.addView(intestazione());
        radice.addView(spazio(26));
        radice.addView(testo(coll ? T.s("collegato") : T.s("cerco"), 21,
                coll ? VERDE : AMBRA, true, Gravity.CENTER));
        radice.addView(spazio(20));
        avvisoStrumento();

        if (meteo) {
            LinearLayout c = cartaVuota();
            c.addView(riga(T.s("qnh"), String.format(Locale.US, "%.0f", LinkService.qnh), "hPa", TESTO));
            if (LinkService.temperaturaC > -90f) {
                c.addView(riga(T.s("temperatura"), String.format(Locale.US, "%.0f",
                        LinkService.temperaturaC), "°", TESTO));
            }
            if (LinkService.rugiadaC > -90f) {
                c.addView(riga(T.s("rugiada"), String.format(Locale.US, "%.0f",
                        LinkService.rugiadaC), "°", TESTO));
            }
            c.addView(riga(T.s("vento"), String.format(Locale.US, "%d° · %.0f", LinkService.dirVento,
                    LinkService.ktVento), "kt", TESTO));
            c.addView(riga(T.s("raffiche"), String.format(Locale.US, "%.0f", LinkService.ktRaffica), "kt", TESTO));
            if (LinkService.visibilitaM >= 0) {
                c.addView(riga(T.s("visib"), String.format(Locale.US, "%.0f",
                        LinkService.visibilitaM / 1000f), "km", TESTO));
            }
            if (LinkService.congelamentoM >= 0) {
                c.addView(riga(T.s("congel"), String.valueOf(LinkService.congelamentoM), "m", TESTO));
            }
            if (LinkService.pioggiaProb >= 0) {
                c.addView(riga(T.s("pioggia"), String.valueOf(LinkService.pioggiaProb), "%", TESTO));
            }
            c.addView(spazio(10));
            long min = (System.currentTimeMillis() - LinkService.meteoAt) / 60000L;
            String q = min <= 0 ? T.s("adesso") : (min + " " + T.s("min_fa"));
            String agg = T.s("aggiornato") + " " + q;
            if (LinkService.meteoDestinazione) agg = agg + "  ·  " + T.s("destinazione");
            c.addView(testo(agg, 13, LinkService.meteoDestinazione ? VERDE : GRIGIO, false, Gravity.START));
            radice.addView(c);
        } else {
            LinearLayout c = cartaVuota();
            final boolean senzaPos = "pos".equals(LinkService.motivo);
            c.addView(testo(senzaPos ? T.s("no_pos") : T.s("no_meteo"), 15, AMBRA, true, Gravity.START));
            if (senzaPos) {
                c.addView(spazio(6));
                c.addView(testo(T.s("no_pos_sub"), 13, GRIGIO, false, Gravity.START));
                if (LinkService.diag != null && LinkService.diag.length() > 0) {
                    c.addView(spazio(8));
                    c.addView(testo(LinkService.diag, 11, 0xFF6B7686, false, Gravity.START));
                }
            }
            radice.addView(c);
        }

        radice.addView(spazio(14));
        radice.addView(testo(coll ? T.s("spegni_schermo") : T.s("cerco_sub"), 13, GRIGIO, false, Gravity.CENTER));
        // Riga tecnica, sempre visibile finche' il meteo non arriva: serve per capire dove si blocca.
        if (!meteo) {
            radice.addView(spazio(14));
            final String m = LinkService.diagMeteo;
            radice.addView(testo(LinkService.diag + "  |  meteo: " + (m.isEmpty() ? "ok" : m),
                    11, 0xFF7B8696, false, Gravity.CENTER));
        }

        radice.addView(spazio(26));
        radice.addView(rigaStrumento());
        radice.addView(spazio(18));
        radice.addView(pulsanteChiudi());
    }

    /** Il riquadro in cima: due in zona e nessuna scelta, oppure il tuo che non si sente. */
    private void avvisoStrumento() {
        if (LinkService.sceltoAssente) {
            final String nome = LinkService.nomeScelto(this);
            LinearLayout c = riquadro(0xFF1B1710, 0xFF4A3A18);
            c.addView(testo(String.format(T.s("non_trovato"), nome == null ? "?" : nome),
                    14, AMBRA, true, Gravity.START));
            c.addView(spazio(6));
            c.addView(testo(T.s("non_trovato_sub"), 13, 0xFFC8B48A, false, Gravity.START));
            if (altriInZona()) {
                c.addView(spazio(6));
                c.addView(testo(T.s("altro_in_zona"), 13, BLU, true, Gravity.START));
                c.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { apriScelta(); }
                });
            }
            radice.addView(c);
            radice.addView(spazio(16));
            return;
        }
        if (LinkService.sceltaDaFare) {
            final String nome = LinkService.nomeCollegato;
            LinearLayout c = riquadro(0xFF1B1710, 0xFF4A3A18);
            c.addView(testo(T.s("due_in_zona"), 14, AMBRA, true, Gravity.START));
            c.addView(spazio(6));
            c.addView(testo(String.format(T.s("due_in_zona_sub"), nome == null ? "?" : nome),
                    13, 0xFFC8B48A, false, Gravity.START));
            c.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { apriScelta(); }
            });
            radice.addView(c);
            radice.addView(spazio(16));
        }
    }

    private boolean altriInZona() {
        final String scelto = LinkService.macScelto(this);
        for (LinkService.Trovato t : LinkService.trovati()) {
            if (scelto == null || !scelto.equals(t.mac)) return true;
        }
        return false;
    }

    /** In fondo: a quale strumento e' legata l'app, e come cambiarlo. */
    private View rigaStrumento() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, px(14), 0, 0);
        View linea = new View(this);
        linea.setBackgroundColor(0xFF1C222A);
        TextView et = testo(T.s("strumento"), 13, GRIGIO, false, Gravity.START);
        r.addView(et);
        String nome = LinkService.nomeScelto(this);
        if (nome == null) nome = LinkService.nomeCollegato;
        if (nome == null) nome = "—";
        TextView nv = testo(nome, 14, TESTO, true, Gravity.START);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = px(8);
        nv.setLayoutParams(lp);
        r.addView(nv);
        r.addView(testo(T.s("cambia"), 13, BLU, true, Gravity.END));
        r.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { apriScelta(); }
        });
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lpl = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, px(1));
        linea.setLayoutParams(lpl);
        box.addView(linea);
        box.addView(r);
        return box;
    }

    /** Chiude davvero: ferma il servizio e esce. */
    private View pulsanteChiudi() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView b = testo(T.s("chiudi_app"), 15, 0xFFE06A6A, true, Gravity.CENTER);
        b.setPadding(px(18), px(13), px(18), px(13));
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(px(16));
        g.setColor(0xFF1A1114);
        g.setStroke(px(1), 0xFF46262A);
        b.setBackground(g);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startService(new Intent(MainActivity.this, LinkService.class)
                            .setAction(LinkService.AZ_CHIUDI));
                } catch (Exception ignored) {
                }
                h.removeCallbacks(aggiorna);
                finishAndRemoveTask();
            }
        });
        box.addView(b);
        box.addView(spazio(8));
        box.addView(testo(T.s("chiudi_sub"), 12, GRIGIO, false, Gravity.CENTER));
        return box;
    }

    private void apriScelta() {
        listaScelta = LinkService.trovati();
        modoScelta = true;
        disegna();
    }

    /** La schermata della scelta: chi si sente adesso, dal piu' forte al piu' debole. */
    private void schermataScelta() {
        TextView ind = testo(T.s("indietro"), 13, BLU, true, Gravity.START);
        ind.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { modoScelta = false; disegna(); }
        });
        radice.addView(ind);
        radice.addView(spazio(22));
        radice.addView(testo(T.s("quale_strumento"), 22, TESTO, true, Gravity.START));
        radice.addView(spazio(7));
        radice.addView(testo(T.s("quale_sub"), 13, GRIGIO, false, Gravity.START));
        radice.addView(spazio(22));

        final String scelto = LinkService.macScelto(this);
        List<LinkService.Trovato> l = listaScelta;
        if (l.isEmpty()) {
            radice.addView(testo(T.s("nessuno_trovato"), 15, AMBRA, true, Gravity.CENTER));
        }
        for (final LinkService.Trovato t : l) {
            final boolean suo = (scelto != null && scelto.equals(t.mac))
                    || (scelto == null && t.nome.equals(LinkService.nomeCollegato));
            LinearLayout c = riquadro(suo ? 0xFF13201A : 0xFF171B21, suo ? VERDE : 0xFF2A313B);
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout testi = new LinearLayout(this);
            testi.setOrientation(LinearLayout.VERTICAL);
            testi.setLayoutParams(new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            testi.addView(testo(t.nome, 18, TESTO, true, Gravity.START));
            String q = t.rssi > -65 ? T.s("seg_forte") : (t.rssi > -85 ? T.s("seg_medio") : T.s("seg_debole"));
            if (suo) q = q + " · " + T.s("in_uso");
            testi.addView(testo(q, 12, suo ? 0xFF8FBFA4 : GRIGIO, false, Gravity.START));
            r.addView(testi);
            r.addView(tacche(t.rssi, suo ? VERDE : GRIGIO));
            c.addView(r);
            c.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    LinkService.scegli(MainActivity.this, t.mac, t.nome);
                    modoScelta = false;
                    disegna();
                }
            });
            radice.addView(c);
            radice.addView(spazio(13));
        }

        radice.addView(spazio(8));
        radice.addView(testo(T.s("scelta_resta"), 13, GRIGIO, false, Gravity.START));
        radice.addView(spazio(22));
        TextView ancora = testo(T.s("cerca_ancora"), 13, BLU, true, Gravity.CENTER);
        ancora.setPadding(0, px(10), 0, px(10));
        ancora.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { apriScelta(); }
        });
        radice.addView(ancora);
    }

    /** Quattro tacche: quante sono accese dipende dalla potenza del segnale. */
    private View tacche(int rssi, int colore) {
        final int n = rssi > -60 ? 4 : rssi > -72 ? 3 : rssi > -85 ? 2 : 1;
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.BOTTOM);
        for (int i = 0; i < 4; i++) {
            View v = new View(this);
            v.setBackgroundColor(i < n ? colore : 0xFF2A313B);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(px(5), px(6 + i * 5));
            lp.leftMargin = px(i == 0 ? 0 : 3);
            v.setLayoutParams(lp);
            r.addView(v);
        }
        return r;
    }

    /** Un riquadro con fondo e bordo propri, come le carte ma colorabile. */
    private LinearLayout riquadro(int fondo, int bordo) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(px(20), px(17), px(20), px(17));
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(px(18));
        g.setColor(fondo);
        g.setStroke(px(1), bordo);
        c.setBackground(g);
        return c;
    }

    // ---- pezzi ----

    private View intestazione() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        logo.setLayoutParams(new LinearLayout.LayoutParams(px(34), px(34)));
        r.addView(logo);
        TextView t = testo("AVEA Link", 18, TESTO, true, Gravity.START);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = px(11);
        t.setLayoutParams(lp);
        r.addView(t);
        // La versione sta attaccata al nome, non all'altro bordo: cosi' si legge come una cosa
        // sola, "AVEA Link 1.8.0", e non sembra un dato a se'.
        TextView ver = testo(versione(), 12, GRIGIO, false, Gravity.START);
        LinearLayout.LayoutParams lpv = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lpv.leftMargin = px(7);
        lpv.bottomMargin = px(2);
        ver.setLayoutParams(lpv);
        r.addView(ver);
        TextView lang = testo(T.s("cambia_lingua"), 13, BLU, true, Gravity.END);
        lang.setPadding(px(10), px(8), px(4), px(8));
        lang.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { T.toggle(MainActivity.this); disegna(); }
        });
        r.addView(lang);
        return r;
    }

    private LinearLayout cartaVuota() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARTA);
        g.setCornerRadius(px(18));
        g.setStroke(px(1), BORDO);
        c.setBackground(g);
        c.setPadding(px(18), px(18), px(18), px(18));
        return c;
    }

    private View carta(String titolo, String sotto, boolean fatto, String etichetta, final Runnable azione) {
        LinearLayout c = cartaVuota();
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = testo(titolo, 16, TESTO, true, Gravity.START);
        t.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        r.addView(t);
        if (fatto) r.addView(testo("✓ " + T.s("fatto"), 14, VERDE, true, Gravity.END));
        c.addView(r);
        c.addView(spazio(6));
        c.addView(testo(sotto, 13, GRIGIO, false, Gravity.START));
        if (!fatto) {
            c.addView(spazio(11));
            c.addView(bottone(etichetta, azione));
        }
        return c;
    }

    private View cartaOrigini() {
        LinearLayout c = cartaVuota();
        c.addView(testo(T.s("origini"), 16, AMBRA, true, Gravity.START));
        c.addView(spazio(7));
        c.addView(testo(T.s("origini_sub"), 13, GRIGIO, false, Gravity.START));
        c.addView(spazio(11));
        c.addView(bottone(T.s("origini_btn"), new Runnable() {
            @Override public void run() { apriOrigini(); }
        }));
        return c;
    }

    private View riga(String etichetta, String valore, String unita, int colore) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.BOTTOM);
        r.setPadding(0, px(7), 0, px(7));
        // Etichetta, valore e unita' uno accanto all'altro: si legge "Temperatura 6 °" come una
        // frase, invece di avere il nome a un bordo e il numero all'altro con il vuoto in mezzo.
        TextView e = testo(etichetta, 14, GRIGIO, false, Gravity.START);
        e.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        r.addView(e);
        TextView v = testo(valore, 22, colore, true, Gravity.START);
        LinearLayout.LayoutParams lpv = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpv.leftMargin = px(9);
        v.setLayoutParams(lpv);
        r.addView(v);
        TextView u = testo(unita, 13, GRIGIO, false, Gravity.START);
        LinearLayout.LayoutParams lpu = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lpu.leftMargin = px(3);
        u.setLayoutParams(lpu);
        r.addView(u);
        return r;
    }

    private TextView testo(String s, int sp, int colore, boolean grassetto, int gravita) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(colore);
        t.setGravity(gravita);
        if (grassetto) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        t.setLineSpacing(px(3), 1f);
        t.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        return t;
    }

    private View bottone(String etichetta, final Runnable azione) {
        Button b = new Button(this);
        b.setText(etichetta);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setTextColor(SCURO);
        GradientDrawable g = new GradientDrawable();
        g.setColor(BLU);
        g.setCornerRadius(px(11));
        b.setBackground(g);
        b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { azione.run(); }
        });
        b.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(48)));
        return b;
    }

    private View spazio(int altezza) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(altezza)));
        return v;
    }

    private View quadrante(int lato, int anello, int lancetta) {
        Quadrante q = new Quadrante(this, anello, lancetta);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(px(lato), px(lato));
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        q.setLayoutParams(lp);
        return q;
    }

    private int px(int d) {
        return Math.round(d * dp);
    }

    /** Numero di versione, in alto a destra: serve a vedere subito cosa c'e' davvero installato. */
    private String versione() {
        try {
            return "v" + getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "v?";
        }
    }

    // ---- azioni ----

    private void chiediBt() {
        List<String> p = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) {
            p.add(Manifest.permission.BLUETOOTH_SCAN);
            p.add(Manifest.permission.BLUETOOTH_CONNECT);
        } else {
            p.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        requestPermissions(p.toArray(new String[0]), CHIEDI);
    }

    private void chiediBatteria() {
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }

    // Porta direttamente alla pagina dove si accende la localizzazione. Se quel pannello non
    // esiste su questo telefono si aprono le impostazioni generali: meglio un passo in piu' che
    // un pulsante che non fa niente.
    private void apriLocalizzazione() {
        try {
            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Exception e2) {
                // niente da fare: la scheda resta, e il conto si rifa' al rientro nell'app
            }
        }
    }

    private void apriOrigini() {
        try {
            Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SECURITY_SETTINGS));
        }
    }

    private void avviaServizio() {
        Intent i = new Intent(this, LinkService.class);
        startForegroundService(i);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] esiti) {
        disegna();
    }

    /** Il quadrante tondo con la lancetta, come lo strumento. */
    private static class Quadrante extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int anello, lancetta;

        Quadrante(Context c, int anello, int lancetta) {
            super(c);
            this.anello = anello;
            this.lancetta = lancetta;
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), hh = getHeight();
            float r = Math.min(w, hh) / 2f;
            float cx = w / 2f, cy = hh / 2f;
            float sp = Math.max(2f, r * 0.055f);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(sp);
            p.setColor(anello);
            c.drawCircle(cx, cy, r - sp, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF131922);
            c.drawCircle(cx, cy, r * 0.74f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(2f, r * 0.07f));
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(lancetta);
            c.drawLine(cx, cy, cx, cy - r * 0.56f, p);
            c.drawLine(cx, cy, cx + r * 0.38f, cy + r * 0.21f, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF3DA5F4);
            c.drawCircle(cx, cy, Math.max(2f, r * 0.085f), p);
        }
    }
}
