package it.avea.link;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.Map;

/** Testi dell'app in italiano e in inglese. La lingua si sceglie alla prima apertura. */
public final class T {

    public static final String IT = "it";
    public static final String EN = "en";

    private static final Map<String, String> it = new HashMap<>();
    private static final Map<String, String> en = new HashMap<>();

    private static String lang = null;

    static {
        p("app", "AVEA Link", "AVEA Link");

        p("scegli_lingua", "Scegli la lingua", "Choose your language");
        p("italiano", "Italiano", "Italiano");
        p("inglese", "English", "English");

        p("titolo_setup", "Il QNH e il vento, dal telefono allo strumento.",
                          "QNH and wind, from your phone to the instrument.");
        p("sotto_setup", "Si prepara da solo. Quattro passi, una volta sola.",
                         "It sets itself up. Four steps, once only.");
        p("fine_setup", "Fatto questo non dovrai piu' toccare niente.",
                        "After this you never have to touch it again.");

        p("bt", "Bluetooth", "Bluetooth");
        p("bt_sub", "Per parlare con lo strumento.", "To talk to the instrument.");
        p("pos", "Posizione", "Location");
        p("pos_sub", "Per chiedere il meteo del posto in cui sei.",
                     "To ask for the weather where you are.");
        p("notif", "Notifiche", "Notifications");
        p("notif_sub", "Per dirti che e' collegato anche a schermo spento.",
                       "So it can tell you it is connected with the screen off.");
        p("batt", "Batteria", "Battery");
        p("batt_sub", "Perche' il telefono non metta l'app a dormire in volo.",
                      "So the phone does not put the app to sleep in flight.");
        p("loc", "Localizzazione accesa", "Location switched on");
        p("loc_sub", "Il permesso non basta: se l'interruttore e' spento il telefono non sa dove sei, "
                   + "e senza posizione non c'e' meteo. Sui telefoni fino ad Android 11 serve anche "
                   + "per trovare lo strumento via Bluetooth.",
                     "The permission is not enough: with the switch off the phone does not know where "
                   + "you are, and with no position there is no weather. On phones up to Android 11 it "
                   + "is also needed to find the instrument over Bluetooth.");

        p("consenti", "Consenti", "Allow");
        p("attiva", "Attiva", "Turn on");
        p("fatto", "Fatto", "Done");
        p("apri", "Apri", "Open");

        p("origini", "Origini sconosciute", "Unknown sources");
        p("origini_sub",
          "L'APK non arriva dal Play Store, quindi la prima volta Android chiede il permesso di installarlo. "
          + "Quando compare l'avviso tocca Impostazioni e attiva \"Consenti da questa origine\" per il browser "
          + "o per Gestione file, poi torna indietro e tocca Installa. Si fa una volta sola, e lo stesso vale "
          + "per i prossimi aggiornamenti.",
          "The APK does not come from the Play Store, so the first time Android asks permission to install it. "
          + "When the warning appears tap Settings and turn on \"Allow from this source\" for your browser "
          + "or for Files, then go back and tap Install. You do this once, and the same applies to future updates.");
        p("origini_btn", "Apri le impostazioni", "Open settings");

        p("collegato", "Collegato ad AVEA", "Connected to AVEA");
        p("cerco", "Cerco l'AVEA...", "Looking for AVEA...");
        p("cerco_sub", "Accendi lo strumento: si collega da solo. Non devi fare niente.",
                       "Switch the instrument on: it connects by itself. You do not have to do anything.");
        // Scelta dello strumento
        p("strumento", "Strumento", "Instrument");
        p("cambia", "cambia", "change");
        p("due_in_zona", "Due strumenti in zona", "Two instruments nearby");
        p("due_in_zona_sub", "Col telefono in tasca mi sono collegata al piu' vicino, %s. Tocca per scegliere.",
                             "With the phone in your pocket I connected to the nearest one, %s. Tap to choose.");
        p("non_trovato", "%s non trovato", "%s not found");
        p("non_trovato_sub", "Continuo a cercare il tuo. Non mi collego a nessun altro.",
                             "I keep looking for yours. I will not connect to any other.");
        p("altro_in_zona", "Ce n'e' un altro in zona. Tocca se vuoi usare quello.",
                           "There is another one nearby. Tap if you want to use it.");
        p("quale_strumento", "Quale strumento", "Which instrument");
        p("quale_sub", "Il numero e' in fondo alla riga MAC della pagina WIFI LOG dello strumento.",
                       "The number is at the end of the MAC line on the instrument's WIFI LOG page.");
        p("in_uso", "in uso adesso", "in use now");
        p("seg_forte", "Segnale forte", "Strong signal");
        p("seg_medio", "Segnale medio", "Medium signal");
        p("seg_debole", "Segnale debole", "Weak signal");
        p("cerca_ancora", "Cerca ancora", "Search again");
        p("indietro", "indietro", "back");
        p("nessuno_trovato", "Nessuno strumento in zona", "No instrument nearby");
        p("scelta_resta", "Quello che scegli resta: da qui in avanti vado solo su di lui, e se non lo trovo aspetto.",
                          "Your choice sticks: from now on I go only to that one, and if I cannot find it I wait.");
        p("chiudi_app", "Chiudi AVEA Link", "Close AVEA Link");
        p("chiudi_sub", "Smette di mandare i dati allo strumento.", "It stops sending data to the instrument.");

        p("spegni_schermo", "Puoi spegnere lo schermo e mettere via il telefono.",
                            "You can switch the screen off and put the phone away.");

        p("qnh", "QNH", "QNH");
        p("temperatura", "Temperatura", "Temperature");
        p("rugiada", "Punto di rugiada", "Dew point");
        p("vento", "Vento", "Wind");
        p("raffiche", "Raffiche", "Gusts");
        p("visib", "Visibilità", "Visibility");
        p("congel", "Zero termico", "Freezing level");
        p("pioggia", "Pioggia", "Rain");
        p("aggiornato", "Aggiornato", "Updated");
        p("min_fa", "min fa", "min ago");
        p("adesso", "adesso", "just now");
        p("no_meteo", "Meteo non disponibile: manca la connessione dati.",
                      "Weather unavailable: no data connection.");
        p("destinazione", "Meteo del campo di destinazione", "Weather at the destination field");
        p("no_pos", "Cerco la posizione del telefono...", "Waiting for the phone's position...");
        p("no_pos_sub", "Se sei in casa puo' volerci qualche minuto. All'aperto e' questione di secondi.",
                        "Indoors this can take a few minutes. Outdoors it takes seconds.");
        p("attesa_meteo", "Scarico il meteo...", "Downloading the weather...");
        p("ultimo", "ULTIMO DATO RICEVUTO", "LAST DATA RECEIVED");
        p("non_valido", "potrebbe non essere piu' valido", "may no longer be valid");

        p("notif_titolo", "AVEA Link", "AVEA Link");
        p("notif_collegato", "Collegato ad AVEA", "Connected to AVEA");
        p("notif_cerco", "Cerco l'AVEA", "Looking for AVEA");

        p("cambia_lingua", "English", "Italiano");
    }

    private static void p(String k, String i, String e) {
        it.put(k, i);
        en.put(k, e);
    }

    public static void load(Context c) {
        SharedPreferences sp = c.getSharedPreferences("avealink", Context.MODE_PRIVATE);
        lang = sp.getString("lang", null);
    }

    public static boolean chosen() {
        return lang != null;
    }

    public static String lang() {
        return lang == null ? IT : lang;
    }

    public static void set(Context c, String l) {
        lang = l;
        c.getSharedPreferences("avealink", Context.MODE_PRIVATE)
                .edit().putString("lang", l).apply();
    }

    public static void toggle(Context c) {
        set(c, EN.equals(lang()) ? IT : EN);
    }

    public static String s(String key) {
        Map<String, String> m = EN.equals(lang()) ? en : it;
        String v = m.get(key);
        return v != null ? v : key;
    }
}
