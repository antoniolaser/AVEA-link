package it.avea.link;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelUuid;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Tiene il collegamento con lo strumento e, ogni tanto, scarica il meteo e glielo manda.
 * Gira come servizio in primo piano: resta vivo a schermo spento, con il telefono in tasca.
 */
public class LinkService extends Service {

    private static final String TAG = "AVEALink";

    // Servizio BLE dello strumento (lo stesso di master e slave) e caratteristica del meteo.
    private static final UUID SVC = UUID.fromString("7a1c0001-5e3d-4b8a-9d4e-a0e1a7e00001");
    private static final UUID MET = UUID.fromString("7a1c0004-5e3d-4b8a-9d4e-a0e1a7e00001");

    private static final long METEO_OGNI_MS = 10 * 60 * 1000L;  // quanto spesso si chiede il meteo
    private static final long INVIO_OGNI_MS = 60 * 1000L;       // quanto spesso si riscrive allo strumento
    private static final String CANALE = "avealink";

    // Stato letto dalla schermata
    public static volatile boolean collegato = false;
    public static volatile boolean meteoOk = false;
    public static volatile float qnh = 0f;
    public static volatile int dirVento = 0;
    public static volatile float ktVento = 0f;
    public static volatile float ktRaffica = 0f;
    public static volatile long meteoAt = 0L;   // SystemClock dell'ultimo meteo riuscito
    // Perche' il meteo non c'e': "" se c'e', "pos" se manca la posizione, "net" se manca la rete.
    public static volatile String motivo = "pos";
    // Riga di diagnostica mostrata nella schermata quando la posizione non si trova.
    public static volatile String diag = "servizio non avviato";
    public static volatile int giri = 0;

    private Location ultimaPos = null;
    private int provAttivi = -1;

    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic charMeteo;
    private boolean scanning = false;
    private final Handler h = new Handler(Looper.getMainLooper());

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        T.load(this);
        creaCanale();
        startForeground(1, notifica());
        BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = bm != null ? bm.getAdapter() : null;
        avviaPosizione();
        h.post(ciclo);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (lm != null) lm.removeUpdates(posCb);
        } catch (SecurityException ignored) {
        }
        fermaScan();
        chiudiGatt();
        collegato = false;
        super.onDestroy();
    }

    // ---- ciclo principale: una volta al minuto guarda cosa c'e' da fare ----

    private final Runnable ciclo = new Runnable() {
        @Override
        public void run() {
            giri++;
            if (!collegato) cercaStrumento();
            if (meteoAt == 0L || System.currentTimeMillis() - meteoAt > METEO_OGNI_MS) scaricaMeteo();
            if (collegato && meteoOk) mandaAlloStrumento();
            aggiornaNotifica();
            h.postDelayed(this, INVIO_OGNI_MS);
        }
    };

    // ---- Bluetooth ----

    private boolean puo(String perm) {
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean puoBt() {
        if (Build.VERSION.SDK_INT >= 31) {
            return puo(Manifest.permission.BLUETOOTH_SCAN) && puo(Manifest.permission.BLUETOOTH_CONNECT);
        }
        return puo(Manifest.permission.ACCESS_FINE_LOCATION);
    }

    private void cercaStrumento() {
        if (adapter == null || !adapter.isEnabled() || scanning || !puoBt()) return;
        try {
            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) return;
            List<ScanFilter> f = new ArrayList<>();
            f.add(new ScanFilter.Builder().setServiceUuid(new ParcelUuid(SVC)).build());
            ScanSettings s = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_POWER).build();
            scanner.startScan(f, s, scanCb);
            scanning = true;
            // lo scan non resta acceso all'infinito: 20 secondi per tentativo
            h.postDelayed(new Runnable() {
                @Override public void run() { fermaScan(); }
            }, 20000);
        } catch (SecurityException e) {
            Log.w(TAG, "scan negato", e);
        }
    }

    private void fermaScan() {
        if (!scanning || scanner == null) return;
        try {
            scanner.stopScan(scanCb);
        } catch (SecurityException ignored) {
        }
        scanning = false;
    }

    private final ScanCallback scanCb = new ScanCallback() {
        @Override
        public void onScanResult(int type, ScanResult r) {
            BluetoothDevice d = r.getDevice();
            if (d == null || gatt != null) return;
            fermaScan();
            try {
                gatt = d.connectGatt(LinkService.this, true, gattCb);
            } catch (SecurityException e) {
                Log.w(TAG, "connessione negata", e);
            }
        }
    };

    private final BluetoothGattCallback gattCb = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt g, int status, int stato) {
            if (stato == BluetoothGatt.STATE_CONNECTED) {
                try {
                    g.discoverServices();
                } catch (SecurityException ignored) {
                }
            } else if (stato == BluetoothGatt.STATE_DISCONNECTED) {
                collegato = false;
                charMeteo = null;
                aggiornaNotifica();
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt g, int status) {
            BluetoothGattService s = g.getService(SVC);
            charMeteo = s != null ? s.getCharacteristic(MET) : null;
            collegato = charMeteo != null;
            if (collegato && meteoOk) mandaAlloStrumento();
            aggiornaNotifica();
        }
    };

    private void chiudiGatt() {
        if (gatt == null) return;
        try {
            gatt.close();
        } catch (SecurityException ignored) {
        }
        gatt = null;
        charMeteo = null;
    }

    /**
     * Dieci byte: versione, flag, QNH x10, direzione, nodi x10, raffica x10.
     * Interi a 16 bit, byte basso per primo (come li legge l'ESP32).
     */
    private void mandaAlloStrumento() {
        if (gatt == null || charMeteo == null) return;
        int q = Math.round(qnh * 10f);
        int kt = Math.round(ktVento * 10f);
        int gu = Math.round(ktRaffica * 10f);
        byte[] b = new byte[10];
        b[0] = 1;
        b[1] = (byte) 0x03;   // bit0 QNH valido, bit1 vento valido
        put16(b, 2, q);
        put16(b, 4, dirVento);
        put16(b, 6, kt);
        put16(b, 8, gu);
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                gatt.writeCharacteristic(charMeteo, b,
                        BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            } else {
                charMeteo.setValue(b);
                charMeteo.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                gatt.writeCharacteristic(charMeteo);
            }
        } catch (SecurityException e) {
            Log.w(TAG, "scrittura negata", e);
        }
    }

    private static void put16(byte[] b, int i, int v) {
        b[i] = (byte) (v & 0xFF);
        b[i + 1] = (byte) ((v >> 8) & 0xFF);
    }

    // ---- meteo ----

    /**
     * Chiede al telefono di tenerci aggiornati sulla posizione. Senza questo, in casa
     * l'ultima posizione conosciuta puo' essere vuota e il meteo non parte mai.
     */
    private final LocationListener posCb = new LocationListener() {
        @Override
        public void onLocationChanged(Location l) {
            if (l == null) return;
            final boolean prima = (ultimaPos == null);
            ultimaPos = l;
            if (prima) {
                // Presa la prima posizione: si rallenta, non serve altro per il meteo.
                try {
                    LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                    if (lm != null) { lm.removeUpdates(posCb); avviaPosizione(); }
                } catch (SecurityException ignored) {
                }
                scaricaMeteo();   // e si scarica subito il meteo, senza aspettare il giro
            }
        }

        @Override public void onProviderEnabled(String p) { }
        @Override public void onProviderDisabled(String p) { }
    };

    private void avviaPosizione() {
        if (!puo(Manifest.permission.ACCESS_COARSE_LOCATION)
                && !puo(Manifest.permission.ACCESS_FINE_LOCATION)) return;
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) return;
        // Un provider alla volta, ognuno con il suo try: se il permesso e' solo "approssimativa",
        // la richiesta sul GPS fallisce, e prima quell'errore faceva saltare anche gli altri.
        // Finche' non abbiamo mai avuto una posizione si chiede con insistenza (un secondo,
        // nessuna distanza minima), come fa l'app AVEA. Appena arriva la prima, si rallenta.
        final long ogni = (ultimaPos == null) ? 1000L : 120000L;
        final float dist = (ultimaPos == null) ? 0f : 2000f;
        int ok = 0;
        for (String p : lm.getProviders(true)) {
            try {
                lm.requestLocationUpdates(p, ogni, dist, posCb, Looper.getMainLooper());
                ok++;
            } catch (SecurityException | IllegalArgumentException e) {
                Log.w(TAG, "provider " + p + " non disponibile", e);
            }
        }
        provAttivi = ok;
        Log.i(TAG, "provider di posizione attivi: " + ok);
        // Android 11 in su: chiede subito una posizione fresca, senza aspettare il primo giro.
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                lm.getCurrentLocation(LocationManager.NETWORK_PROVIDER, null,
                        getMainExecutor(), new java.util.function.Consumer<Location>() {
                            @Override public void accept(Location l) { if (l != null) ultimaPos = l; }
                        });
                lm.getCurrentLocation(LocationManager.GPS_PROVIDER, null,
                        getMainExecutor(), new java.util.function.Consumer<Location>() {
                            @Override public void accept(Location l) { if (l != null) ultimaPos = l; }
                        });
            } catch (SecurityException | IllegalArgumentException e) {
                Log.w(TAG, "posizione immediata non disponibile", e);
            }
        }
    }

    private Location dovesono() {
        if (!puo(Manifest.permission.ACCESS_COARSE_LOCATION)
                && !puo(Manifest.permission.ACCESS_FINE_LOCATION)) {
            diag = "giri " + giri + " | PERMESSO POSIZIONE MANCANTE";
            return null;
        }
        Location best = ultimaPos;
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) {
            diag = "giri " + giri + " | nessun servizio di posizione nel telefono";
            return best;
        }
        // Anche qui un try per ogni fornitore: con il permesso "approssimativa" la lettura del
        // GPS fallisce, e prima quell'errore faceva saltare anche la rete, che invece risponde.
        StringBuilder d = new StringBuilder();
        for (String p : lm.getProviders(true)) {
            try {
                Location l = lm.getLastKnownLocation(p);
                d.append(p).append(l == null ? ":-" : ":ok").append(' ');
                if (l == null) continue;
                if (best == null || l.getTime() > best.getTime()) best = l;
            } catch (SecurityException e) {
                d.append(p).append(":negato ");
            }
        }
        final boolean fine = puo(Manifest.permission.ACCESS_FINE_LOCATION);
        diag = "giri " + giri + " | " + d + (fine ? "| precisa" : "| approssimativa")
                 + (ultimaPos != null ? " | aggiornamenti ok" : " | nessun aggiornamento")
                 + " | prov " + provAttivi;
        return best;
    }

    private void scaricaMeteo() {
        final Location l = dovesono();
        if (l == null) {
            motivo = "pos";   // non e' la rete: il telefono non sa ancora dov'e'
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection c = null;
                try {
                    String u = String.format(Locale.US,
                            "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f"
                            + "&current=pressure_msl,wind_speed_10m,wind_direction_10m,wind_gusts_10m"
                            + "&wind_speed_unit=kn",
                            l.getLatitude(), l.getLongitude());
                    c = (HttpURLConnection) new URL(u).openConnection();
                    c.setConnectTimeout(12000);
                    c.setReadTimeout(12000);
                    if (c.getResponseCode() != 200) return;
                    StringBuilder sb = new StringBuilder();
                    BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
                    String ln;
                    while ((ln = r.readLine()) != null) sb.append(ln);
                    r.close();
                    JSONObject cur = new JSONObject(sb.toString()).getJSONObject("current");
                    qnh = (float) cur.getDouble("pressure_msl");
                    dirVento = (int) Math.round(cur.getDouble("wind_direction_10m"));
                    ktVento = (float) cur.getDouble("wind_speed_10m");
                    ktRaffica = (float) cur.getDouble("wind_gusts_10m");
                    meteoAt = System.currentTimeMillis();
                    meteoOk = true;
                    motivo = "";
                } catch (Exception e) {
                    motivo = "net";
                    Log.w(TAG, "meteo non riuscito", e);
                } finally {
                    if (c != null) c.disconnect();
                }
            }
        }).start();
    }

    // ---- notifica ----

    private void creaCanale() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel ch = new NotificationChannel(CANALE, "AVEA Link",
                NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);
    }

    private Notification notifica() {
        String riga;
        if (collegato && meteoOk) {
            riga = String.format(Locale.US, "QNH %.0f  ·  %s %d° %.0f kt",
                    qnh, T.s("vento"), dirVento, ktVento);
        } else if (collegato) {
            riga = "pos".equals(motivo) ? T.s("no_pos") : T.s("no_meteo");
        } else {
            riga = T.s("cerco_sub");
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CANALE)
                .setContentTitle(collegato ? T.s("notif_collegato") : T.s("notif_cerco"))
                .setContentText(riga)
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void aggiornaNotifica() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(1, notifica());
    }
}
