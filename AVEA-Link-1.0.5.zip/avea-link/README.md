# AVEA Link

App Android che porta **QNH, vento e raffiche** dal telefono allo strumento AVEA, via Bluetooth.
Non serve l'hotspot: il telefono usa i suoi dati, scarica il meteo e manda allo strumento dieci byte.

L'app non contiene niente dell'app AVEA: nessuna schermata, nessun disegno, nessun font.

## Come si crea l'APK

Carica questo progetto (o il suo zip) nella pagina principale del repository. GitHub compila da solo
e mette l'APK in **Releases**, pronto da scaricare dal telefono.

## I quattro Secrets della firma

Senza questi, l'APK esce firmato con la chiave di debug: si installa, ma non si aggiorna sopra una
versione firmata con la chiave vera. Si mettono in *Settings → Secrets and variables → Actions*:

| Secret | Valore |
|---|---|
| `AVEA_KEYSTORE_BASE64` | il file `avea.jks` convertito in base64 |
| `AVEA_STORE_PASSWORD` | la password del keystore |
| `AVEA_KEY_ALIAS` | l'alias della chiave |
| `AVEA_KEY_PASSWORD` | la password della chiave |

Per il base64: `base64 -w0 avea.jks > avea_keystore_base64.txt` e incolla il contenuto.

**Il file `avea.jks` non va mai messo nel repository**: il `.gitignore` lo tiene fuori.

## Come parla con lo strumento

Si aggancia al servizio BLE che l'AVEA ha gia' (`7a1c0001-…`, lo stesso di master e slave) e scrive
sulla caratteristica **`7a1c0004-5e3d-4b8a-9d4e-a0e1a7e00001`**.

Dieci byte, interi a 16 bit con il byte basso per primo:

| byte | contenuto |
|---|---|
| 0 | versione del formato (1) |
| 1 | flag: bit0 QNH valido, bit1 vento valido |
| 2-3 | QNH × 10 (10163 = 1016,3 hPa) |
| 4-5 | direzione del vento in gradi |
| 6-7 | intensita' in nodi × 10 |
| 8-9 | raffica in nodi × 10 |

Lo strumento mette l'ora di arrivo da se': non la riceve. Cosi' sa sempre quanto e' vecchio il dato.

## Da dove viene il meteo

Da **Open-Meteo**, che non chiede nessuna chiave. L'app domanda `pressure_msl`, `wind_speed_10m`,
`wind_direction_10m` e `wind_gusts_10m` per la posizione del telefono, ogni dieci minuti.

Attenzione: Open-Meteo e' gratuito per uso non commerciale. Se lo strumento viene venduto, serve
il loro abbonamento oppure un'altra fonte.

## File

- `app/src/main/java/it/avea/link/MainActivity.java` — le schermate (lingua, configurazione, stato)
- `app/src/main/java/it/avea/link/LinkService.java` — servizio in primo piano: BLE e meteo
- `app/src/main/java/it/avea/link/T.java` — tutti i testi, italiano e inglese
- `download.html` — la pagina da mettere accanto all'APK, con le istruzioni per le origini sconosciute
